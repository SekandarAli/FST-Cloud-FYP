package com.example.fstsignin

class vertical_recycle_main_model {


        var name : String
        var description : String
        var rating : String
        var image : Int


        constructor(name : String,description : String, rating : String,image : Int)
        {
            this.name = name
            this.description = description
            this.rating = rating
            this.image = image
        }

    }
