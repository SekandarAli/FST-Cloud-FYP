package com.example.fstsignin

class food_main_vertical_model {


    var name : String
    var description : String
    var rating : String
    var image : Int


    constructor(name : String,description : String, rating : String,image : Int)
    {
        this.name = name
        this.description = description
        this.rating = rating
        this.image = image
    }
}