package com.example.fstsignin

class food_main_horizontal_list_model {

    var name : String
    var image : Int


    constructor(name : String,image : Int)
    {
        this.name = name
        this.image = image
    }
}