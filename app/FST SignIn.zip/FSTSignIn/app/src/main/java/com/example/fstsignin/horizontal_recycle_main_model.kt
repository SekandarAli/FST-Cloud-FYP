package com.example.fstsignin

class horizontal_recycle_main_model
{

    var name : String
    var image : Int


    constructor(name : String,image : Int)
    {
        this.name = name
        this.image = image
    }

}